AION QUANT LABS — FIRST REAL BROKER-HOSTED *PAPER* OPTION ORDER
==============================================================

BETA, MANUAL CONFIRMATION ONLY. NO WEBHOOK OR AUTOMATIC ORDER ROUTING.
All trading calls are constrained to the verified ALPACA-PAPER trade-enabled
connection and a matching Alpaca Paper account, never Webull or live Alpaca.

Prerequisites:
- Your existing C:\Users\sathw\AION-Execution\.env remains local; do not share it.
- AION_MODE=SIMULATION stays unchanged. Do not enable LIVE.
- Your SnapTrade Personal API key must have paper trade permission.
- Open Alpaca Paper in browser and find a genuinely listed same-day SPY option.
- This first trial is limited to 1 contract and <= $300 paper premium before fees.
- Run 'buy' only 09:35–14:45 New York time on a regular market day.
- This does not fetch live option quotes, verify quote freshness or confirm the contract is currently tradable; YOU must do that in Alpaca Paper before submitting.

1. Extract package into C:\Users\sathw\AION-Execution; do not delete or overwrite .env.
2. Open PowerShell:

   cd C:\Users\sathw\AION-Execution
   .\.venv\Scripts\python.exe -m pip install snaptrade-python-sdk python-dotenv
   .\.venv\Scripts\python.exe .\aion_alpaca_paper_trade.py check

3. When ready during market hours, open Alpaca Paper > SPY > Options, select today's expiry, see the actual option ASK and strike. Then:

   .\.venv\Scripts\python.exe .\aion_alpaca_paper_trade.py buy

   Enter CALL/PUT, displayed strike, and a LIMIT price per share from the current option ASK (not the SPY underlying price). Carefully review max paper debit and type the full consent phrase to submit. THE 'buy' COMMAND *CAN* PLACE ONE SIMULATED ORDER IN YOUR ALPACA PAPER BROKER ACCOUNT. NOT REAL MONEY. It cannot submit to Webull. No order is sent until the confirmation phrase is entered.

4. After reviewing the paper order in Alpaca, reconcile a confirmed execution:

   .\.venv\Scripts\python.exe .\aion_alpaca_paper_trade.py sync

   Re-run 'sync' after a little while if the order is pending. This makes a SnapTrade real-time order-detail request, which may incur SnapTrade usage fees depending on plan. 'sync' never places orders.

5. Open your AION dashboard (localhost 8501 or Tailscale) > Options Executions / Fills. Only 'EXECUTED' status with exact OCC, quantity, price and timestamp is added to the PAPER journal; no order acknowledgment is recorded as a fill. The Source field will be 'ALPACA_PAPER_SNAPTRADE_FEES_UNAVAILABLE'; $0 recorded fees means UNKNOWN fees, not necessarily zero.

IMPORTANT:
- This first trial implements only BUY_TO_OPEN. If the option remains open, close it manually inside Alpaca Paper before the end of its expiration-day session (or let it expire, but that is NOT testing AION exits). The follow-up step is automatic SELL_TO_CLOSE and risk management after we validate the first fill.
- If an order is rejected, pending, partial, or uncertain, DO NOT repeat 'buy' without reviewing the Alpaca account. The tool deliberately prevents repeated submission of the same OCC symbol on the same day.
- SnapTrade lists Alpaca Paper single-leg options trading as supported but specifically lists the **option impact preview as unsupported**. We therefore show an app-computed maximum premium from YOUR manually entered limit. No market quotes or estimated fees are represented as verified.
- AION_MODE=SIMULATION remains required. Nothing turns on live trading or binds this workflow to the public TV webhook.
- Your existing synthetic AION PAPER demo fills are separate and are not claimed to be genuine broker activity.

Official documentation:
https://support.snaptrade.com/brokerages
https://docs.snaptrade.com/reference/Trading/Trading_placeMlegOrder
https://docs.snaptrade.com/docs/order-impact-and-confirmation
https://docs.alpaca.markets/us/docs/options-trading
