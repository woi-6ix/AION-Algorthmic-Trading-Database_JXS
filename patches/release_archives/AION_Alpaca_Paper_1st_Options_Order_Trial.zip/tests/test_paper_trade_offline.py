"""Offline no-order safety checks for the Alpaca Paper SnapTrade trial."""
import importlib.util
import sqlite3
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

SOURCE=Path(__file__).resolve().parents[1] / 'aion_alpaca_paper_trade.py'
spec=importlib.util.spec_from_file_location('aion_alpaca_paper_trade', SOURCE)
mod=importlib.util.module_from_spec(spec)
import sys
sys.modules['aion_alpaca_paper_trade']=mod
spec.loader.exec_module(mod)

CONNECTIONS=[
 {'id':'live-connection-id', 'type':'trade','disabled':False,'brokerage':{'slug':'WEBULL-CANADA'}},
 {'id':'paper-connection-id', 'type':'trade','disabled':False,'brokerage':{'slug':'ALPACA-PAPER'}}]
ACCOUNTS=[
 {'id':'11111111-1111-1111-1111-111111111111','institution_name':'Webull Canada', 'name':'Webull CASH','status':'open','account_category':'INVESTMENT','brokerage_authorization':'live-connection-id'},
 {'id':'22222222-2222-2222-2222-222222222222','institution_name':'Webull Canada', 'name':'Webull MARGIN','status':'open','account_category':'INVESTMENT','brokerage_authorization':'live-connection-id'},
 {'id':'33333333-3333-3333-3333-333333333333','institution_name':'Alpaca Paper', 'name':'Alpaca Paper','status':'open','account_category':'INVESTMENT','brokerage_authorization':'paper-connection-id'}]


def test_paper_account_filters_webull():
    a=mod.paper_account_from_responses(ACCOUNTS, CONNECTIONS)
    assert a['institution_name']=='Alpaca Paper'
    assert a['id'].startswith('333')


def test_fails_closed_on_unverified_paper_connection():
    with pytest.raises(RuntimeError): mod.paper_account_from_responses(ACCOUNTS,[CONNECTIONS[0]])
    with pytest.raises(RuntimeError): mod.paper_account_from_responses(ACCOUNTS,[dict(CONNECTIONS[1],type='read')])
    with pytest.raises(RuntimeError): mod.paper_account_from_responses(ACCOUNTS,[dict(CONNECTIONS[1],disabled=True)])
    with pytest.raises(RuntimeError): mod.paper_account_from_responses(ACCOUNTS + [dict(ACCOUNTS[2],id='44444444-4444-4444-4444-444444444444')],CONNECTIONS)


def test_trial_is_exact_same_day_occ():
    d=datetime(2026,11,5,11,0,tzinfo=ZoneInfo('America/New_York'))
    ticket=mod.make_ticket('C','720','1.23',d)
    assert ticket.occ=='SPY   261105C00720000'
    assert ticket.notional==123
    with pytest.raises(ValueError): mod.make_ticket('P','720','3.01',d)
    with pytest.raises(ValueError): mod.make_ticket('C','720','1.23',d.replace(hour=15))
    with pytest.raises(ValueError): mod.make_ticket('C','720','1.23',d.replace(day=7))


def test_duplicate_is_latched_before_any_api_request(tmp_path,monkeypatch):
    monkeypatch.setattr(mod,'DB',tmp_path/'test.sqlite3')
    d=datetime(2026,11,5,11,0,tzinfo=ZoneInfo('America/New_York'))
    ticket=mod.make_ticket('P','720','0.50',d)
    a=mod.reserve_once(ACCOUNTS[-1]['id'],ticket)
    with pytest.raises(RuntimeError): mod.reserve_once(ACCOUNTS[-1]['id'],ticket)
    assert a
    with sqlite3.connect(mod.DB) as db:
        assert db.execute('SELECT state FROM paper_order_trials').fetchone()[0]=='SUBMISSION_IN_PROGRESS'


def test_acks_do_not_count_as_fills():
    d=datetime(2026,11,5,11,0,tzinfo=ZoneInfo('America/New_York'))
    t=mod.make_ticket('C','720','1.25',d)
    d0={'status':'ACCEPTED','filled_quantity':'0','execution_price':None,'time_executed':None,'option_symbol':{'ticker':t.occ}}
    assert mod.validate_confirmed_detail(d0,t)[0] is None
    d1={'status':'EXECUTED','filled_quantity':'1','execution_price':'1.21','time_executed':'2026-11-05T16:00:11Z','option_symbol':{'ticker':t.occ}}
    assert mod.validate_confirmed_detail(d1,t)[0]['premium']==1.21
    with pytest.raises(RuntimeError): mod.validate_confirmed_detail(dict(d1,option_symbol={'ticker':'SPY   261105P00720000'}),t)
