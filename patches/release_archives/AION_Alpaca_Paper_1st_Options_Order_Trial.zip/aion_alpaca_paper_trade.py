"""AION / SnapTrade ALPACA-PAPER ONLY, explicit-confirmation one-contract SPY 0DTE trial.

No TradingView webhooks, public HTTP routes, background execution or live brokerage accounts.
No orders without an interactive typed confirmation. First-version entry only.
'sync' records actual executed/filled paper orders into AION's read-only journal.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime, time, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'aion_alpaca_paper_orders.sqlite3'
NY = ZoneInfo('America/New_York')
OCC = re.compile(r'^SPY   (\d{6})([CP])(\d{8})$')
MAX_PAPER_PREMIUM = Decimal('300.00')
ACTION = 'BUY_TO_OPEN'
SOURCE = 'ALPACA_PAPER_SNAPTRADE_FEES_UNAVAILABLE'


def plain(value: Any):
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if isinstance(value, dict):
        return {k: plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [plain(x) for x in value]
    if hasattr(value, 'body'):
        return plain(value.body)
    if hasattr(value, 'model_dump'):
        return plain(value.model_dump())
    if hasattr(value, 'to_dict'):
        return plain(value.to_dict())
    return None


def body_list(v, *keys):
    v = plain(v)
    if isinstance(v, list):
        return v
    if isinstance(v, dict):
        for key in ('result', 'data', *keys):
            if isinstance(v.get(key), list):
                return v[key]
        for key in ('result', 'data'):
            if isinstance(v.get(key), dict):
                return body_list(v[key], *keys)
    raise ValueError('Unexpected SnapTrade list response; no order submitted')


def get_client():
    try:
        from dotenv import load_dotenv
        from snaptrade_client import SnapTrade, SnapTradeAuth
    except ImportError:
        raise RuntimeError('Install snaptrade-python-sdk and python-dotenv into your existing .venv')
    load_dotenv(ROOT / '.env', override=False)
    if os.getenv('AION_MODE', 'SIMULATION').upper().strip() != 'SIMULATION':
        raise RuntimeError('AION_MODE must stay SIMULATION for this paper-only test')
    client_id = os.getenv('SNAPTRADE_CLIENT_ID', '').strip()
    key = os.getenv('SNAPTRADE_CONSUMER_KEY', '').strip()
    if not client_id or not key:
        raise RuntimeError('SnapTrade Personal API credentials missing from local .env. Never paste keys into chat.')
    return SnapTrade(auth=SnapTradeAuth.personal_api_key(client_id=client_id, consumer_key=key))


def paper_account_from_responses(accounts, connections):
    """Require exact institution & connection cross-match; no fallback account."""
    cs = body_list(connections, 'connections', 'authorizations')
    eligible_connections = []
    for connection in cs:
        if not isinstance(connection, dict):
            continue
        broker = connection.get('brokerage') or {}
        if not isinstance(broker, dict):
            continue
        if (broker.get('slug') == 'ALPACA-PAPER' and
                connection.get('type') == 'trade' and
                connection.get('disabled') is False and
                isinstance(connection.get('id'), str)):
            eligible_connections.append(connection['id'])
    if len(eligible_connections) != 1:
        raise RuntimeError('Expected exactly one active ALPACA-PAPER trade connection; refusing any brokerage fallback')
    ac = body_list(accounts, 'accounts')
    eligible = []
    for account in ac:
        if not isinstance(account, dict):
            continue
        conn = account.get('brokerage_authorization') or account.get('connection')
        if isinstance(conn, dict):
            conn = conn.get('id')
        if (conn == eligible_connections[0] and
                account.get('institution_name') == 'Alpaca Paper' and
                account.get('name') == 'Alpaca Paper' and
                account.get('status') == 'open' and
                account.get('account_category') == 'INVESTMENT' and
                re.fullmatch(r'[a-fA-F0-9-]{36}', str(account.get('id', '')))):
            eligible.append(account)
    if len(eligible) != 1:
        raise RuntimeError('Cannot uniquely identify an OPEN Alpaca Paper account; no order submitted')
    return eligible[0]


def find_paper_account(client):
    ac = client.account_information.list_user_accounts()
    co = client.connections.list_brokerage_authorizations()
    return paper_account_from_responses(ac, co)


def usd_cash(balance_response) -> Decimal:
    rows = body_list(balance_response, 'balances')
    for x in rows:
        if not isinstance(x, dict):
            continue
        cur = x.get('currency') or {}
        cc = cur.get('code') if isinstance(cur, dict) else str(cur)
        if cc == 'USD':
            v = x.get('cash')
            if v is None:
                raise RuntimeError('Alpaca Paper USD cash balance unavailable')
            return Decimal(str(v))
    raise RuntimeError('Could not verify Alpaca Paper USD cash; no order submitted')


def local_market_window(now: datetime) -> bool:
    now = now.astimezone(NY)
    return now.weekday() < 5 and time(9, 35) <= now.time() < time(14, 45)


@dataclass(frozen=True)
class Ticket:
    occ: str
    action: str
    limit: Decimal
    notional: Decimal
    side: str
    strike: Decimal
    expiry: str


def make_ticket(right: str, strike: str, limit: str, now: datetime) -> Ticket:
    now = now.astimezone(NY)
    if not local_market_window(now):
        raise ValueError('Trading test only permitted 09:35–14:45 ET, weekdays, not market holidays')
    right = right.upper().strip()
    if right not in ('C', 'P'):
        raise ValueError('Choose C for CALL or P for PUT')
    try:
        st = Decimal(str(strike))
        li = Decimal(str(limit))
    except (InvalidOperation, TypeError):
        raise ValueError('Invalid decimal input') from None
    if (not st.is_finite() or not li.is_finite() or not Decimal('1') <= st <= Decimal('2000') or
            st * 1000 != (st * 1000).to_integral_value() or
            li < Decimal('0.01') or li.as_tuple().exponent < -2):
        raise ValueError('Strike or premium is not a valid price')
    cost = li * 100
    if cost > MAX_PAPER_PREMIUM:
        raise ValueError(f'One-contract premium ${cost:.2f} exceeds trial cap ${MAX_PAPER_PREMIUM:.2f}')
    occ = f"{'SPY':<6}{now:%y%m%d}{right}{int(st * 1000):08d}"
    if not OCC.fullmatch(occ):
        raise ValueError('Invalid OCC symbol')
    return Ticket(occ, ACTION, li, cost, 'CALL' if right == 'C' else 'PUT', st, now.date().isoformat())


def initialize():
    with sqlite3.connect(DB) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS paper_order_trials(
            intent TEXT PRIMARY KEY,
            account_id TEXT NOT NULL,
            option_symbol TEXT NOT NULL,
            date_ny TEXT NOT NULL,
            action TEXT NOT NULL,
            limit_price TEXT NOT NULL,
            state TEXT NOT NULL,
            brokerage_order_id TEXT,
            created_at TEXT NOT NULL,
            last_seen TEXT,
            last_status TEXT
        )''')
        db.commit()


def reserve_once(account_id, ticket):
    initialize()
    intent = f'{ticket.expiry}:{ticket.occ}:{ACTION}'
    with sqlite3.connect(DB, timeout=10) as db:
        try:
            db.execute('''INSERT INTO paper_order_trials(
              intent, account_id, option_symbol, date_ny, action, limit_price, state, created_at)
              VALUES(?, ?, ?, ?, ?, ?, 'SUBMISSION_IN_PROGRESS', ?)''',
              (intent, account_id, ticket.occ, ticket.expiry, ACTION, str(ticket.limit),
               datetime.now(timezone.utc).isoformat()))
            db.commit()
        except sqlite3.IntegrityError:
            raise RuntimeError('Trial already attempted for this exact SPY option today. No duplicate sent.') from None
    return intent


def remember_response(intent, data):
    x = plain(data)
    if not isinstance(x, dict):
        raise RuntimeError('Unrecognized order response. Submission status UNKNOWN: inspect Alpaca Paper manually before retry.')
    order_id = x.get('brokerage_order_id') or ''
    if not order_id:
        orders = x.get('orders', [])
        if isinstance(orders, list) and len(orders) == 1 and isinstance(orders[0], dict):
            order_id = orders[0].get('brokerage_order_id') or ''
    if not isinstance(order_id, str) or not order_id:
        raise RuntimeError('No brokerage order ID returned. Submission status UNKNOWN; check Alpaca Paper manually.')
    with sqlite3.connect(DB) as db:
        db.execute('UPDATE paper_order_trials SET state=?, brokerage_order_id=?, last_seen=? WHERE intent=?',
                   ('SUBMITTED_NOT_FILLED', order_id, datetime.now(timezone.utc).isoformat(), intent))
        db.commit()
    return order_id


def validate_confirmed_detail(detail, ticket: Ticket):
    x = plain(detail)
    if isinstance(x, dict) and isinstance(x.get('result'), dict):
        x = x['result']
    if not isinstance(x, dict):
        raise ValueError('Order detail unavailable')
    status = str(x.get('status', '')).upper()
    if status != 'EXECUTED':
        return None, status
    opt = x.get('option_symbol') or {}
    symbol = opt.get('ticker') if isinstance(opt, dict) else ''
    if symbol != ticket.occ:
        raise RuntimeError('Order detail option symbol mismatch; refusing journal write')
    filled = x.get('filled_quantity')
    px = x.get('execution_price')
    at = x.get('time_executed')
    try:
        confirmed_qty = Decimal(str(filled)) == Decimal('1')
    except (InvalidOperation, TypeError):
        confirmed_qty = False
    if not confirmed_qty or px is None or not at:
        raise ValueError('Executed order lacks a validated 1-contract fill, price or execution time')
    p = Decimal(str(px))
    if not p.is_finite() or p <= 0:
        raise ValueError('Invalid execution price')
    stamp = datetime.fromisoformat(str(at).replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('Execution timestamp lacks timezone')
    return {'filled_at':stamp.isoformat(), 'premium':float(p), 'contracts':1}, status


def print_account(client, account):
    # A single live SnapTrade READ against the selected and verified paper account.
    balances = client.account_information.get_user_account_balance(account_id=account['id'])
    cash = usd_cash(balances)
    print('VERIFIED: ALPACA-PAPER / trade-enabled / account OPEN')
    print(f'Simulated USD cash reported by SnapTrade: ${cash:,.2f}')
    print('Webull CASH/MARGIN never selected for order routing.')
    return cash


def run_check():
    client = get_client()
    account = find_paper_account(client)
    print_account(client, account)
    print('Account verified. No order placed. Options permission/contract listing still need broker validation.')


def ask_ticket():
    print('\nOpen Alpaca Paper > Options > SPY. Select TODAY\'S 0DTE contract.')
    print('Copy the listed strike and current option ASK; do not use a stock price or old quote.')
    right = input('Call or Put? [C/P]: ').strip().upper()
    strike = input('Listed SPY strike (e.g. 720): ').strip()
    limit = input('Maximum LIMIT option premium per share in USD (e.g. 1.25): ').strip()
    return make_ticket(right, strike, limit, datetime.now(NY))


def run_buy():
    if not sys.stdin.isatty():
        raise RuntimeError('Trade needs an interactive local terminal; no webhooks or unattended automation')
    client = get_client()
    account = find_paper_account(client)
    cash = print_account(client, account)
    t = ask_ticket()
    if cash < t.notional + Decimal('10'):
        raise RuntimeError('Insufficient verified simulated USD cash; no paper order submitted')
    if not local_market_window(datetime.now(NY)):
        raise RuntimeError('Market trial window closed before submission; no order sent')
    print('\nPAPER BROKER: Alpaca Paper ONLY')
    print('Symbol:', repr(t.occ), ' | ', t.side, ' | Strike:', t.strike, '| Expiry:', t.expiry)
    print('Action: BUY_TO_OPEN | 1 contract | LIMIT / Day')
    print(f'Maximum PAPER premium debit: ${t.notional:.2f} USD before any fees')
    print('Quote source: MANUALLY ENTERED from Alpaca Paper option chain; not independently verified')
    print('Broker impact preview: NOT SUPPORTED for Alpaca Paper')
    print('A limit may not fill. Any order submitted remains a simulated Alpaca paper order.')
    phrase = 'PLACE 1 ALPACA PAPER OPTION'
    entered = input(f'Type exactly "{phrase}" to submit this PAPER order (anything else cancels): ').strip()
    if entered != phrase:
        print('CANCELED. No order sent.')
        return
    # One last hard account and market-window verification immediately before sending.
    account2 = find_paper_account(client)
    if account2['id'] != account['id'] or not local_market_window(datetime.now(NY)):
        raise RuntimeError('Account or market window changed; refusing order')
    intent = reserve_once(account['id'], t)
    leg = {'instrument': {'symbol': t.occ, 'instrument_type': 'OPTION'},
           'action': ACTION, 'units': 1}
    try:
        answer = client.trading.place_mleg_order(account_id=account['id'],
                  order_type='LIMIT', time_in_force='Day', limit_price=str(t.limit),
                  price_effect='DEBIT', legs=[leg])
    except Exception as exc:
        # NEVER automatically retry a potentially sent order.
        print('Paper submission failed or is uncertain:', type(exc).__name__)
        print('DO NOT retry the command before checking Alpaca Paper open orders.')
        print('No live brokerage account can be targeted by this script.')
        return
    try:
        order_id = remember_response(intent, answer)
    except RuntimeError as exc:
        print(str(exc))
        return
    print('Alpaca Paper order accepted for processing. Order ID suffix:', order_id[-6:])
    print('NOT YET A CONFIRMED FILL. To sync confirmed fills to AION, run:')
    print(r'.\.venv\Scripts\python.exe .\aion_alpaca_paper_trade.py sync')


def ticket_from_row(row):
    match = OCC.fullmatch(row['option_symbol'])
    if not match:
        raise ValueError('Stored OCC mismatch')
    return Ticket(row['option_symbol'], row['action'], Decimal(row['limit_price']),
                  Decimal(row['limit_price'])*100, 'CALL' if match.group(2)=='C' else 'PUT',
                  Decimal(match.group(3))/1000, row['date_ny'])


def run_sync():
    client = get_client()
    account = find_paper_account(client)
    print('Sync source: verified Alpaca Paper only. No orders will be sent.')
    initialize()
    from aion_execution_journal import record_fill, DEFAULT_DB
    with sqlite3.connect(DB) as db:
        db.row_factory = sqlite3.Row
        records = [dict(r) for r in db.execute(
            "SELECT * FROM paper_order_trials WHERE brokerage_order_id IS NOT NULL AND state != 'JOURNALED' ORDER BY created_at").fetchall()]
    if not records:
        print('No pending broker-tracked orders. Nothing to sync.')
        return
    for record in records:
        if record['account_id'] != account['id']:
            print('Skipping nonmatching account ID in local journal; no write.')
            continue
        order_id = record['brokerage_order_id']
        try:
            detail = client.account_information.get_user_account_order_detail(
                account_id=account['id'], brokerage_order_id=order_id)
            trade, status = validate_confirmed_detail(detail, ticket_from_row(record))
        except Exception as exc:
            print('Could not verify paper order detail:', type(exc).__name__)
            print('No fill was recorded. Check order status in Alpaca Paper manually.')
            continue
        print('Paper order ending', order_id[-6:], 'broker status:', status or 'UNKNOWN')
        if trade is None:
            with sqlite3.connect(DB) as db:
                db.execute('UPDATE paper_order_trials SET last_status=?, last_seen=? WHERE intent=?',
                           (status, datetime.now(timezone.utc).isoformat(), record['intent']))
                db.commit()
            continue
        fill_id = 'alpaca-paper-' + re.sub(r'[^a-zA-Z0-9-]', '-', order_id)[:100]
        try:
            inserted = record_fill(
                fill_id=fill_id, filled_at=trade['filled_at'], option_symbol=record['option_symbol'],
                mode='PAPER', action=record['action'], contracts=1,
                fill_price=trade['premium'], fees_usd=0.0,
                source=SOURCE, broker_order_id=order_id, db_path=DEFAULT_DB)
        except Exception as exc:
            print('Journal write refused:', type(exc).__name__)
            continue
        with sqlite3.connect(DB) as db:
            db.execute('UPDATE paper_order_trials SET state=?, last_status=?, last_seen=? WHERE intent=?',
                       ('JOURNALED', status, datetime.now(timezone.utc).isoformat(), record['intent']))
            db.commit()
        print('CONFIRMED PAPER fill', 'recorded' if inserted else 'previously recorded',
              f'1 contract @ ${trade["premium"]:.2f}/share')
        print('Broker fee data unavailable; journal uses 0.00 as a placeholder, NOT a verified fee.')
    print('Review in AION > Options Executions / Fills. Read-only dashboard auto-refreshes.')


def main(argv=None):
    parser = argparse.ArgumentParser(description='ALPACA-PAPER ONLY. One-contract SPY 0DTE demo; no live accounts.')
    parser.add_argument('command', choices=('check', 'buy', 'sync'))
    args = parser.parse_args(argv)
    try:
        if args.command == 'check':
            run_check()
        elif args.command == 'buy':
            run_buy()
        else:
            run_sync()
    except (RuntimeError, ValueError, ImportError, OSError) as exc:
        print('STOP:', str(exc))
        sys.exit(1)
    except Exception as exc:
        print('STOP: unexpected failure:', type(exc).__name__)
        print('No automatic order retries. Never share API credentials or raw exception objects.')
        sys.exit(2)


if __name__ == '__main__':
    main()
