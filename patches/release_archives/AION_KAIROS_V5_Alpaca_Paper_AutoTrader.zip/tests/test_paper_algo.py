import importlib.util
import os
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from decimal import Decimal

import pytest

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import aion_alpaca_paper_algo as bot


@pytest.fixture()
def sandbox(tmp_path,monkeypatch):
    monkeypatch.setattr(bot,'STATE',tmp_path/'bot.sqlite3')
    monkeypatch.setattr(bot,'SIGNALS',tmp_path/'signals.sqlite3')
    monkeypatch.setattr(bot,'KILL',tmp_path/'kill.txt')
    monkeypatch.setattr(bot,'LOCK',tmp_path/'lock.txt')
    monkeypatch.setenv('AION_MODE','SIMULATION')
    monkeypatch.setenv('ALPACA_PAPER_API_KEY','paper_dummy')
    monkeypatch.setenv('ALPACA_PAPER_SECRET_KEY','paper_secret_dummy')
    bot.init_db()
    bot.put_cfg('paper_account_id','PAPER-ONLY-UUID')
    bot.put_cfg('armed','true')
    bot.put_cfg('armed_at',(bot.now_utc()-timedelta(minutes=2)).isoformat())
    return tmp_path


class FakeApi:
    def __init__(self):
        self.submits=[]
        self.current_order=None
        self.position=[]
        self.open=[]
    def account(self):return {'id':'PAPER-ONLY-UUID','status':'ACTIVE','cash':'100000',
            'options_trading_level':2,'account_blocked':False,'trading_blocked':False}
    def clock(self):return {'is_open':True}
    def positions(self):return self.position
    def orders(self):return self.open
    def stock_spy(self):return Decimal('744.75')
    def contracts(self, expiry, right):
        code='C' if right=='call' else 'P'
        return [dict(symbol=f'SPY{expiry[2:4]}{expiry[5:7]}{expiry[8:10]}{code}00745000',
                     underlying_symbol='SPY',expiration_date=expiry,type=right,
                     tradable=True,multiplier='100',strike_price='745')]
    def snapshot(self,symbols):
        return {s:{'latestQuote':{'bp':1.20,'ap':1.25,'t':bot.now_utc().isoformat()},
                   'greeks':{'delta':0.45}} for s in symbols}
    def submit(self,body):
        self.submits.append(body)
        self.current_order=dict(body,id='paper-order-1',status='new',filled_qty='0',filled_avg_price=None,filled_at=None)
        return self.current_order
    def order_by_client_id(self,cid):
        return self.current_order if self.current_order and self.current_order['client_order_id']==cid else None


def test_no_live_host_can_be_configured(monkeypatch):
    assert bot.TRADING=='https://paper-api.alpaca.markets'
    assert bot.DATA=='https://data.alpaca.markets'
    monkeypatch.setenv('AION_MODE','LIVE')
    monkeypatch.setenv('ALPACA_PAPER_API_KEY','f')
    monkeypatch.setenv('ALPACA_PAPER_SECRET_KEY','f')
    with pytest.raises(RuntimeError,match='SIMULATION'):
        bot.AlpacaPaper()


def test_account_binding(sandbox):
    api=FakeApi()
    assert bot.broker_account_check(api,'PAPER-ONLY-UUID')['status']=='ACTIVE'
    with pytest.raises(RuntimeError,match='MISMATCH'):
        bot.broker_account_check(api,'WEBULL-CASH')


def test_non_spy_or_expired_not_allowed(sandbox,monkeypatch):
    a=FakeApi()
    fake_time=datetime(2026,11,5,15,0,tzinfo=timezone.utc)
    assert bot.market_window('ENTRY',fake_time)
    with pytest.raises(RuntimeError,match='SPY 0DTE'):
        bot.submit_intent(a,'test1','BUY_TO_OPEN','AAPL261105C00745000','1.00',current=fake_time)
    with pytest.raises(RuntimeError,match='SPY 0DTE'):
        bot.submit_intent(a,'test2','BUY_TO_OPEN','SPY261106C00745000','1.00',current=fake_time)
    with pytest.raises(RuntimeError,match='risk cap'):
        bot.submit_intent(a,'test3','BUY_TO_OPEN','SPY261105C00745000','3.50',current=fake_time)


def test_contract_quote_selection(sandbox,monkeypatch):
    t=datetime(2026,11,5,15,0,tzinfo=timezone.utc)
    monkeypatch.setattr(bot,'now_utc',lambda:t)
    a=FakeApi()
    x=bot.select_contract(a,'BUY_CALL',current=t)
    assert x['symbol']=='SPY261105C00745000'
    assert x['ask']==Decimal('1.25')
    assert x['underlying']==Decimal('744.75')
    assert x['right']=='call'


def test_order_submission_one_contract_and_unique_id(sandbox,monkeypatch):
    t=datetime(2026,11,5,15,0,tzinfo=timezone.utc)
    monkeypatch.setattr(bot,'now_utc',lambda:t)
    a=FakeApi()
    r=bot.submit_intent(a,'evA','BUY_TO_OPEN','SPY261105C00745000','1.26',current=t)
    order=a.submits[0]
    assert r['status']=='new'
    assert order['qty']=='1' and order['side']=='buy'
    assert order['position_intent']=='buy_to_open' and order['type']=='limit'
    assert order['time_in_force']=='day' and order['limit_price']=='1.26'
    with pytest.raises(RuntimeError,match='Duplicate'):
        bot.submit_intent(a,'evA','BUY_TO_OPEN','SPY261105C00745000','1.26',current=t)
    assert len(a.submits)==1


def test_unknown_submission_cannot_retry(sandbox,monkeypatch):
    t=datetime(2026,11,5,15,0,tzinfo=timezone.utc)
    monkeypatch.setattr(bot,'now_utc',lambda:t)
    a=FakeApi()
    def fail(body):raise RuntimeError('network timeout')
    a.submit=fail
    with pytest.raises(RuntimeError,match='UNKNOWN'):
        bot.submit_intent(a,'ev-error','BUY_TO_OPEN','SPY261105C00745000','1.26',current=t)
    assert bot.orders_db()[0]['state']=='UNKNOWN_SUBMISSION'
    with pytest.raises(RuntimeError,match='Duplicate'):
        bot.submit_intent(a,'ev-error','BUY_TO_OPEN','SPY261105C00745000','1.26',current=t)


def test_signal_stale_and_independent(sandbox):
    with sqlite3.connect(bot.SIGNALS) as con:
        con.execute('CREATE TABLE events(event_id TEXT, received_at TEXT, signal TEXT, result TEXT, strategy TEXT, symbol TEXT)')
        con.execute('INSERT INTO events VALUES (?,?,?,?,?,?)',('old', (bot.now_utc()-timedelta(minutes=20)).isoformat(),'BUY_CALL','SIGNAL_LOGGED','KAIROS_V5','SPY'))
        con.execute('INSERT INTO events VALUES (?,?,?,?,?,?)',('fake',bot.now_utc().isoformat(),'BUY_CALL','IGNORED_ALREADY_SIGNALED','KAIROS_V5','SPY'))
    assert bot.accepted_events()==[]


def test_paper_fill_journal_reconciliation(sandbox,monkeypatch):
    # Load original AION journal implementation from provided user's AION package.
    import zipfile
    archive=Path('/mnt/data/AION_Live_Mobile_Trading_Dashboard.zip')
    if not archive.exists():pytest.skip('original test fixture unavailable')
    with zipfile.ZipFile(archive) as z:
        raw=z.read('aion_execution_journal.py')
    journal_file=sandbox/'aion_execution_journal.py'
    journal_file.write_bytes(raw)
    spec=importlib.util.spec_from_file_location('aion_execution_journal',journal_file)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    sys.modules['aion_execution_journal']=module
    db=sandbox/'aion_execution_journal.sqlite3'
    monkeypatch.setattr(module,'DEFAULT_DB',db)
    a=FakeApi()
    cid='aionpv5-abc123'
    with sqlite3.connect(bot.STATE) as conn:
        conn.execute('''INSERT INTO paper_orders(client_order_id,event_id,submitted_at,action,option_symbol,qty,state)
                        VALUES(?,?,?,?,?,1,'new')''',(cid,'evt',bot.now_utc().isoformat(),'BUY_TO_OPEN','SPY261105C00745000'))
    a.current_order={'id':'paperorder-1','client_order_id':cid,'symbol':'SPY261105C00745000',
                     'status':'filled','filled_qty':'1','filled_avg_price':'1.23',
                     'filled_at':bot.now_utc().isoformat()}
    x=bot.sync_orders(a)
    assert x[0][1]=='filled'
    fills=module.read_fills(db)
    assert len(fills)==1
    assert fills[0]['option_symbol']=='SPY   261105C00745000'
    assert fills[0]['source']=='ALPACA_PAPER_API_FEES_NOT_CONFIRMED'
    assert bot.sync_orders(a)[0][2]=='already_journaled'
    assert len(module.read_fills(db))==1


def test_web_ui_has_no_trade_routes():
    import aion_alpaca_paper_panel as ui
    paths={r.path:sorted(r.methods or []) for r in ui.app.routes}
    assert not any('POST' in m or 'DELETE' in m for m in paths.values())


def test_accepted_tradingview_signal_submits_only_paper_order(sandbox,monkeypatch):
    # Read the simulator's accepted-events schema; bypass the public gateway entirely.
    n=datetime(2026,11,5,15,0,tzinfo=timezone.utc)
    monkeypatch.setattr(bot,'now_utc',lambda:n)
    bot.put_cfg('armed_at',(n-timedelta(minutes=1)).isoformat())
    with sqlite3.connect(bot.SIGNALS) as conn:
        conn.execute('''CREATE TABLE events (event_id TEXT, received_at TEXT, signal TEXT,
            result TEXT, strategy TEXT,symbol TEXT)''')
        conn.execute('INSERT INTO events VALUES(?,?,?,?,?,?)',
                     ('tvv5-123',n.isoformat(),'BUY_CALL','SIGNAL_LOGGED','KAIROS_V5','SPY'))
    a=FakeApi()
    results=bot.process_events(a)
    assert results and 'ENTRY_new' in results[0][1]
    assert len(a.submits)==1
    assert a.submits[0]['symbol']=='SPY261105C00745000'
    assert a.submits[0]['side']=='buy'
    # Same event, even if poll runs twice, never submits twice.
    assert bot.process_events(a)==[]
    assert len(a.submits)==1


def test_kill_switch_refuses_order(sandbox,monkeypatch):
    t=datetime(2026,11,5,15,0,tzinfo=timezone.utc)
    monkeypatch.setattr(bot,'now_utc',lambda:t)
    a=FakeApi()
    bot.KILL.write_text('emergency')
    with pytest.raises(RuntimeError,match='Not armed'):
        bot.submit_intent(a,'evt','BUY_TO_OPEN','SPY261105C00745000','1.23',current=t)
    assert len(a.submits)==0
