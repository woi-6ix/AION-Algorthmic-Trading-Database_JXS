"""AION / SnapTrade Webull Canada CASH-only SPY 0DTE *non-executing* diagnostics.

Commands:
  account                  Live READ of selected CASH brokerage account
  ticket [params]          Offline limit order ticket (no broker call)
  preview [params]         Live READ-ONLY option order impact (BETA, NO ORDER)

SECURITY: NO order submission code is implemented in this module or package.
NEVER import this file from the public TradingView webhook gateway. The gateway
and simulator remain simulation-only.  No SnapTrade secrets are logged.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, date, time
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import os
from pathlib import Path
import re
import sys
from typing import Any
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
NY = ZoneInfo("America/New_York")
STRIKE_MIN, STRIKE_MAX = Decimal("1"), Decimal("10000")
MAX_CONTRACTS = 10
OCC_PATTERN = re.compile(r"^SPY   \d{6}[CP]\d{8}$")


def config() -> dict[str, str]:
    try:
        from dotenv import load_dotenv
    except ImportError:
        raise RuntimeError("Missing dependency: run .\\.venv\\Scripts\\python.exe -m pip install python-dotenv snaptrade-python-sdk")
    load_dotenv(ROOT / ".env")
    mode = os.environ.get("AION_MODE", "SIMULATION").strip().upper()
    if mode != "SIMULATION":
        raise RuntimeError("Refusing to run: AION_MODE must be SIMULATION")
    if os.environ.get("AION_ALLOWED_STRATEGY", "KAIROS_V5").strip() != "KAIROS_V5":
        raise RuntimeError("Only KAIROS_V5 is supported")
    fields = {k: os.environ.get(k, "").strip() for k in (
        "SNAPTRADE_CLIENT_ID", "SNAPTRADE_CONSUMER_KEY", "SNAPTRADE_CASH_ACCOUNT_ID"
    )}
    missing = [k for k, v in fields.items() if not v]
    if missing:
        raise RuntimeError("Missing .env settings: " + ", ".join(missing))
    return fields


def get_client(fields: dict[str, str]):
    from snaptrade_client import SnapTrade, SnapTradeAuth
    return SnapTrade(auth=SnapTradeAuth.personal_api_key(
        client_id=fields["SNAPTRADE_CLIENT_ID"],
        consumer_key=fields["SNAPTRADE_CONSUMER_KEY"],
    ))


def plain(o: Any) -> Any:
    """Convert SDK response objects to dictionaries without formatting secrets."""
    if isinstance(o, (str, int, float, bool, type(None))):
        return o
    if isinstance(o, dict):
        return {k: plain(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [plain(x) for x in o]
    if hasattr(o, "model_dump"):
        return plain(o.model_dump())
    if hasattr(o, "to_dict"):
        return plain(o.to_dict())
    if hasattr(o, "__dict__"):
        return plain({k: v for k, v in vars(o).items() if not k.startswith("_")})
    return None


def _list_connections(body: Any) -> list[dict[str, Any]]:
    """Normalize the documented SnapTrade list-connections response."""
    value = plain(body)
    if isinstance(value, dict):
        value = value.get("result", value.get("data", value.get("connections")))
    if not isinstance(value, list) or any(not isinstance(c, dict) for c in value):
        raise RuntimeError("Unexpected SnapTrade connection response; refusing to proceed")
    return value


def verify_cash_details(details: Any, selected_id: str,
                        connections: Any) -> dict[str, Any]:
    """Require exact CASH account ID + verified Webull Canada trade connection.

    SnapTrade account `display_name` is user-defined/institution-defined, and
    MUST NOT be used to authenticate a brokerage. The account's `connection_id`
    binds the account to a verified broker connection with slug WEBULL-CANADA.
    """
    d = plain(details)
    if isinstance(d, dict) and isinstance(d.get("account"), dict):
        d = d["account"]
    if not isinstance(d, dict):
        raise RuntimeError("Unrecognized account details format; refusing to proceed")
    returned_id = str(d.get("id") or d.get("account_id") or "")
    if not returned_id or returned_id != selected_id:
        raise RuntimeError("Account ID mismatch; refusing to proceed")
    kind = str(d.get("kind") or "investment").lower()
    if kind != "investment":
        raise RuntimeError("Selected account is not an investment account")
    name = str(d.get("display_name") or d.get("name") or "(unnamed)")
    raw_type = str(d.get("raw_type") or d.get("account_type") or "").upper()
    cash_or_margin = str(d.get("cash_or_margin") or "").upper()
    if "MARGIN" in raw_type or "MARGIN" in cash_or_margin:
        raise RuntimeError("Account is MARGIN; refusing to proceed")
    if cash_or_margin != "CASH":
        raise RuntimeError("SnapTrade has not explicitly confirmed cash_or_margin=CASH")
    if d.get("is_paper") is not False:
        raise RuntimeError("Broker account is paper or paper status is unknown; refusing to proceed")
    if str(d.get("status") or "open").lower() not in ("open",):
        raise RuntimeError("Broker account is not open; refusing to proceed")

    connection_id = str(d.get("connection_id") or d.get("brokerage_authorization_id") or "")
    if not connection_id:
        raise RuntimeError("Account response lacks connection_id; cannot verify brokerage")
    matches = [c for c in _list_connections(connections) if str(c.get("id") or "") == connection_id]
    if len(matches) != 1:
        raise RuntimeError("Account's brokerage connection could not be uniquely verified")
    conn = matches[0]
    brokerage = conn.get("brokerage")
    if not isinstance(brokerage, dict):
        raise RuntimeError("Missing brokerage details for selected account")
    slug = str(brokerage.get("slug") or "").upper()
    if slug != "WEBULL-CANADA":
        raise RuntimeError("Selected account is not linked to WEBULL-CANADA; refusing to proceed")
    if conn.get("disabled") is not False:
        raise RuntimeError("Brokerage connection is disabled or its state is unknown")
    if str(conn.get("type") or "").lower() != "trade":
        raise RuntimeError("Brokerage connection is not trade-enabled")
    if brokerage.get("allows_trading") is not True or brokerage.get("enabled") is not True:
        raise RuntimeError("Brokerage trading permission or availability not verified")
    return {"name": name, "account_type": cash_or_margin,
            "paper": False, "brokerage": "Webull Canada"}


def checked_client():
    f = config()
    client = get_client(f)
    details = client.account_information.get_account_details(
        account_id=f["SNAPTRADE_CASH_ACCOUNT_ID"]
    ).body
    connections = client.connections.list_brokerage_authorizations().body
    safe = verify_cash_details(details, f["SNAPTRADE_CASH_ACCOUNT_ID"], connections)
    return client, f, safe


def decimal_number(v: str, field: str) -> Decimal:
    try:
        d = Decimal(str(v))
    except (InvalidOperation, ValueError):
        raise ValueError(f"{field} must be a decimal number") from None
    if not d.is_finite() or d <= 0:
        raise ValueError(f"{field} must be positive and finite")
    return d


@dataclass(frozen=True)
class Ticket:
    right: str
    strike: Decimal
    expiry: date
    limit: Decimal
    contracts: int
    symbol: str
    maximum_premium_usd: Decimal
    max_allowed_usd: Decimal


def build_ticket(right: str, strike: str, limit: str, contracts: int,
                 expiry: date | None = None, today: date | None = None,
                 budget: str = "2500") -> Ticket:
    if today is None:
        today = datetime.now(NY).date()
    if expiry is None:
        expiry = today
    if expiry != today:
        raise ValueError("AION only prepares same-calendar-day 0DTE contracts (New York date)")
    if expiry.weekday() >= 5:
        raise ValueError("0DTE expiry cannot be a weekend")
    right = right.upper().strip()
    if right not in ("C", "P"):
        raise ValueError("right must be C for call or P for put")
    st = decimal_number(strike, "strike")
    if st < STRIKE_MIN or st > STRIKE_MAX or st.as_tuple().exponent < -3:
        raise ValueError("strike outside supported range or more than 3 decimals")
    if (st * Decimal(1000)) != (st * Decimal(1000)).to_integral_value():
        raise ValueError("strike is not a multiple of $0.001")
    lim = decimal_number(limit, "limit")
    if lim != lim.quantize(Decimal("0.01")):
        raise ValueError("limit must have at most 2 decimal places")
    if not 1 <= contracts <= MAX_CONTRACTS:
        raise ValueError(f"contracts must be between 1 and {MAX_CONTRACTS}")
    budget_d = decimal_number(budget, "budget")
    premium = lim * Decimal(100) * contracts
    if premium > budget_d:
        raise ValueError(f"Maximum premium ${premium} exceeds configured cap ${budget_d}")
    strike_000 = int((st * 1000).to_integral_value(rounding=ROUND_HALF_UP))
    occ = f"{'SPY':<6}{expiry:%y%m%d}{right}{strike_000:08d}"
    if len(occ) != 21 or not OCC_PATTERN.fullmatch(occ):
        raise RuntimeError("Failed to build OCC symbol")
    return Ticket(right, st, expiry, lim, contracts, occ, premium, budget_d)


def print_ticket(t: Ticket, account: str = "Webull CASH (configured ID hidden)") -> None:
    now = datetime.now(NY)
    print("\nAION SPY 0DTE ORDER TICKET — NO ORDER PLACED")
    print("Account: ", account)
    print("Contract:", t.symbol)
    print("Right:   ", "CALL" if t.right == "C" else "PUT", " | Strike: $", t.strike,
          " | Expiry: ", t.expiry, sep="")
    print(f"Action: BUY_TO_OPEN | Contracts: {t.contracts} | Order: LIMIT / Day")
    print(f"Entered limit: ${t.limit:.2f} per option share (NOT a verified live quote)")
    print(f"Maximum option premium: ${t.maximum_premium_usd:.2f} USD before fees/FX")
    print(f"Configured premium cap: ${t.max_allowed_usd:.2f} USD")
    print("Source: MANUALLY ENTERED — no option quote or OCC listing validation")
    print("Fees/FX/cash availability: UNKNOWN. Brokerage order acceptance: NOT TESTED.")
    print("Current New York time:", now.strftime("%Y-%m-%d %H:%M:%S %Z"))
    if not (now.weekday() < 5 and time(9, 30) <= now.time() < time(14, 45)):
        print("WARNING: Outside AION's configured 09:30-14:45 ET entry window.")
    print("Execution mode: SIMULATION | Broker orders: DISABLED BY DESIGN\n")


def safe_preview_error(exc: Exception) -> str:
    """Minimal broker error details; never print the exception body, tokens or UUIDs."""
    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    b = getattr(exc, "body", None)
    code, downstream_status = None, None
    if isinstance(b, dict):
        code = b.get("code")
        detail = str(b.get("detail", ""))
    elif isinstance(b, str):
        import json
        try:
            obj = json.loads(b)
        except ValueError:
            obj = {}
        code = obj.get("code") if isinstance(obj, dict) else None
        detail = str(obj.get("detail", "")) if isinstance(obj, dict) else ""
    else:
        detail = ""
    hit = re.search(r"status code (\d{3})", detail)
    if hit:
        downstream_status = hit.group(1)
    return f"HTTP status: {status or 'unknown'}; error code: {code or 'unknown'}; downstream status: {downstream_status or 'unknown'}"


def ensure_preview_window(now: datetime | None = None) -> None:
    """Fail closed before invoking the beta brokerage impact API outside entry hours.

    Preview is not order placement. This gate avoids sending same-day options
    orders to a market that is already closed / contract that has expired.
    US market holidays still need separate exchange calendar verification.
    """
    local = (now or datetime.now(NY)).astimezone(NY)
    if local.weekday() >= 5 or not (time(9, 30) <= local.time() < time(14, 45)):
        raise RuntimeError(
            "Preview blocked outside 09:30-14:45 America/New_York. "
            "Use a currently listed SPY 0DTE contract and recent broker bid/ask "
            "during the next US trading session. No SnapTrade request sent."
        )


def request_impact(client, account_id: str, ticket: Ticket) -> dict[str, Any]:
    """Only non-trading SnapTrade BETA impact call, NOT order placement."""
    leg = {"instrument": {"symbol": ticket.symbol, "instrument_type": "OPTION"},
           "action": "BUY_TO_OPEN", "units": ticket.contracts}
    body = client.trading.get_option_impact(
        account_id=account_id,
        order_type="LIMIT",
        time_in_force="Day",
        limit_price=f"{ticket.limit:.2f}",
        price_effect="DEBIT",
        legs=[leg],
    ).body
    return plain(body)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Webull Canada CASH-only AION options preflight. NO ORDER SUBMISSION.")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("account", help="READ ONLY: verify selected Webull CASH account")
    sub.add_parser("preview-window", help="Check local New York preview test window; no API requests")
    for command in ("ticket", "preview"):
        s = sub.add_parser(command, help="Offline ticket" if command == "ticket" else "BETA impact preview, NO order")
        s.add_argument("--right", required=True, choices=("C", "P"), help="C=long call, P=long put")
        s.add_argument("--strike", required=True, help="Actual option strike from your broker chain")
        s.add_argument("--limit", required=True, help="Manually obtained limit price per option share")
        s.add_argument("--contracts", type=int, default=1)
        s.add_argument("--expiry", help="YYYY-MM-DD; defaults to today's New York date (0DTE only)")
    return p


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.cmd == "preview-window":
            ensure_preview_window()
            print("Preview time window OPEN (09:30-14:45 ET). No API call performed.")
            return 0
        if args.cmd == "account":
            _, _, details = checked_client()
            print("SUCCESS: Selected brokerage account was verified")
            print("Broker:", details["brokerage"])
            print("Account label:", details["name"])
            print("Type:", details["account_type"])
            print("Order placement code: NONE; broker orders sent: 0")
            return 0
        f = config()  # fail closed even for offline ticket if wrong AION config
        budget = os.getenv("AION_MAX_OPTION_PREMIUM_USD", "2500")
        expiry = date.fromisoformat(args.expiry) if args.expiry else None
        t = build_ticket(args.right, args.strike, args.limit, args.contracts,
                         expiry=expiry, budget=budget)
        print_ticket(t)
        if args.cmd == "ticket":
            print("Ticket validation complete. Nothing was sent to SnapTrade.\n")
            return 0
        # Recheck local US entry hours immediately before the broker API request.
        ensure_preview_window()
        # ONLY the get_option_impact beta endpoint. No place-option-order method used.
        client, f, details = checked_client()
        print("Broker-verified account:", details["name"])
        try:
            result = request_impact(client, f["SNAPTRADE_CASH_ACCOUNT_ID"], t)
        except Exception as exc:
            print("SNAPTRADE OPTION IMPACT (BETA) FAILED:", safe_preview_error(exc))
            print("This is NOT evidence that order placement fails. No order attempted.")
            print("Send only the codes above to support; never share .env or your API keys.")
            return 2
        print("BROKERAGE OPTION IMPACT PREVIEW (BETA):")
        if isinstance(result, dict):
            for key in ("estimated_cash_change", "cash_change_direction", "estimated_fee_total"):
                if key in result:
                    print(f"  {key}: {result[key]}")
            if not any(key in result for key in ("estimated_cash_change", "cash_change_direction", "estimated_fee_total")):
                print("Preview returned data but no recognized estimate fields; schema may have changed.")
        else:
            print("Preview succeeded with an unfamiliar response schema; no order submitted.")
        print("Order submission: NOT IMPLEMENTED. Brokerage orders sent: 0")
        return 0
    except (RuntimeError, ValueError, ImportError) as exc:
        print("STOP:", str(exc))
        return 1
    except Exception as exc:
        print("Broker/API check failed:", safe_preview_error(exc))
        print("No order submission method exists in this program.")
        return 2

if __name__ == "__main__":
    sys.exit(main())
