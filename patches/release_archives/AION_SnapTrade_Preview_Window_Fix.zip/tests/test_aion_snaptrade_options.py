import sys
import unittest
from datetime import date, datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from aion_snaptrade_options import build_ticket, verify_cash_details, safe_preview_error, checked_client, ensure_preview_window, NY

TODAY = date(2026, 11, 5)


def make_cash():
    return {
        'kind': 'investment', 'id': 'test-cash-001', 'connection_id': 'auth-webull-ca-001',
        'display_name': 'CASH', 'raw_type': 'CASH', 'cash_or_margin': 'cash',
        'is_paper': False, 'status': 'open',
    }


def make_connection():
    return {
        'id': 'auth-webull-ca-001', 'type': 'trade', 'disabled': False,
        'brokerage': {'slug': 'WEBULL-CANADA', 'enabled': True, 'allows_trading': True},
    }


class TestTicket(unittest.TestCase):
    def test_spy_0dte_call_occ(self):
        t = build_ticket('C', '680', '2.50', 1, today=TODAY)
        self.assertEqual(t.symbol, 'SPY   261105C00680000')
        self.assertEqual(len(t.symbol), 21)
        self.assertEqual(t.maximum_premium_usd, 250)

    def test_put_occ(self):
        t = build_ticket('P', '679.5', '0.75', 2, today=TODAY)
        self.assertEqual(t.symbol, 'SPY   261105P00679500')
        self.assertEqual(t.maximum_premium_usd, 150)

    def test_budget_rejection(self):
        with self.assertRaises(ValueError):
            build_ticket('C', '680', '26.00', 1, today=TODAY)

    def test_nonzero_positive_prices_and_precision(self):
        for x in ('0', '-1', 'NaN', '2.555'):
            with self.assertRaises(ValueError):
                build_ticket('C', '680', x, 1, today=TODAY)

    def test_not_0dte(self):
        with self.assertRaises(ValueError):
            build_ticket('P', '670', '1.50', 1, expiry=date(2026, 11, 6), today=TODAY)

    def test_weekend(self):
        with self.assertRaises(ValueError):
            build_ticket('P', '670', '1.50', 1, today=date(2026, 11, 7))

    def test_cash_with_custom_name_and_verified_connection(self):
        safe = verify_cash_details(make_cash(), 'test-cash-001', [make_connection()])
        self.assertEqual(safe['brokerage'], 'Webull Canada')
        self.assertEqual(safe['account_type'], 'CASH')

    def test_reject_margin_even_if_name_says_cash(self):
        d = {**make_cash(), 'raw_type': 'MARGIN', 'display_name': 'Webull CASH'}
        with self.assertRaisesRegex(RuntimeError, 'MARGIN'):
            verify_cash_details(d, 'test-cash-001', [make_connection()])

    def test_reject_margin_normalized(self):
        d = {**make_cash(), 'cash_or_margin': 'margin'}
        with self.assertRaises(RuntimeError):
            verify_cash_details(d, 'test-cash-001', [make_connection()])

    def test_reject_account_id_mismatch(self):
        with self.assertRaises(RuntimeError):
            verify_cash_details(make_cash(), 'test-other', [make_connection()])

    def test_reject_unrelated_broker(self):
        c = make_connection()
        c['brokerage'] = {**c['brokerage'], 'slug': 'OTHER-BROKER'}
        with self.assertRaises(RuntimeError):
            verify_cash_details(make_cash(), 'test-cash-001', [c])

    def test_reject_no_connection(self):
        with self.assertRaises(RuntimeError):
            verify_cash_details(make_cash(), 'test-cash-001', [])

    def test_reject_read_only_connection(self):
        c = {**make_connection(), 'type': 'read'}
        with self.assertRaises(RuntimeError):
            verify_cash_details(make_cash(), 'test-cash-001', [c])

    def test_reject_disabled_connection(self):
        c = {**make_connection(), 'disabled': True}
        with self.assertRaises(RuntimeError):
            verify_cash_details(make_cash(), 'test-cash-001', [c])

    def test_reject_paper_or_unknown_paper_status(self):
        for status in (True, None):
            d = {**make_cash(), 'is_paper': status}
            with self.assertRaises(RuntimeError):
                verify_cash_details(d, 'test-cash-001', [make_connection()])

    def test_reject_missing_brokerage_id(self):
        d = {**make_cash()}
        d.pop('connection_id')
        with self.assertRaises(RuntimeError):
            verify_cash_details(d, 'test-cash-001', [make_connection()])

    def test_preview_error_codes_only(self):
        class FakeException(Exception):
            status_code = 503
            body = {'code': 3002, 'detail': 'request failed with status code 417', 'secret': 'DO_NOT_SHOW'}
        result = safe_preview_error(FakeException())
        self.assertIn('503', result)
        self.assertIn('3002', result)
        self.assertIn('417', result)
        self.assertNotIn('DO_NOT_SHOW', result)

    def test_preview_window_allowed_inside_session(self):
        ensure_preview_window(datetime(2026, 11, 5, 10, 30, tzinfo=NY))

    def test_preview_window_rejects_expired_after_hours(self):
        with self.assertRaisesRegex(RuntimeError, "Preview blocked"):
            ensure_preview_window(datetime(2026, 11, 4, 19, 32, tzinfo=NY))

    def test_preview_window_rejects_weekend(self):
        with self.assertRaises(RuntimeError):
            ensure_preview_window(datetime(2026, 11, 7, 10, 30, tzinfo=NY))

    def test_checked_client_links_account_and_connection_without_orders(self):
        class FakeAccountInformation:
            def get_account_details(self, account_id):
                self.requested_account = account_id
                return SimpleNamespace(body=make_cash())
        class FakeConnections:
            def list_brokerage_authorizations(self):
                return SimpleNamespace(body=[make_connection()])
        client = SimpleNamespace(account_information=FakeAccountInformation(),
                                 connections=FakeConnections())
        with patch('aion_snaptrade_options.config', return_value={'SNAPTRADE_CASH_ACCOUNT_ID': 'test-cash-001'}), \
             patch('aion_snaptrade_options.get_client', return_value=client):
            result_client, _, details = checked_client()
        self.assertIs(result_client, client)
        self.assertEqual(details['brokerage'], 'Webull Canada')

if __name__ == '__main__':
    unittest.main()
