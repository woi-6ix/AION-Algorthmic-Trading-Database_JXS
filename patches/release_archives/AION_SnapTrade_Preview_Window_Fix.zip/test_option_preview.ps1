$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'This uses SnapTrade BETA get_option_impact (preview only).'
Write-Host 'NO BROKERAGE ORDER WILL BE SENT, even if the preview succeeds.'
& .\.venv\Scripts\python.exe .\aion_snaptrade_options.py preview-window
if ($LASTEXITCODE -ne 0) { throw 'Preview blocked: outside 09:30-14:45 ET; do not retry an expired 0DTE option. Confirm NYSE is open independently.' }
Write-Host 'In Webull, confirm the SPY contract is listed and use a CURRENT bid/ask. Do not use yesterday''s expiry.'
$right = (Read-Host 'Option right (C=CALL, P=PUT)').Trim().ToUpper()
$strike = (Read-Host 'Strike price from Webull 0DTE option chain').Trim()
$limit = (Read-Host 'Limit premium per option share USD, from your own option quote').Trim()
$contracts = (Read-Host 'Number of contracts').Trim()
& .\.venv\Scripts\python.exe .\aion_snaptrade_options.py preview --right $right --strike $strike --limit $limit --contracts $contracts
if ($LASTEXITCODE -ne 0) { throw "Impact preview returned an error (exit $LASTEXITCODE); no order placed" }
Write-Host 'Brokerage orders placed: 0'
