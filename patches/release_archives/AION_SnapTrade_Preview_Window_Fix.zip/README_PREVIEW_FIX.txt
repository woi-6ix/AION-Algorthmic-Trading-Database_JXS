AION KAIROS V5 SnapTrade Preview Window Fix (2026-11-04)

Fix type: safety/diagnostic — this does NOT resolve an unknown upstream 417 error.

Installation in Windows PowerShell:
cd C:\Users\sathw\AION-Execution
Copy-Item .\aion_snaptrade_options.py .\aion_snaptrade_options.py.bak
Expand-Archive -Path "$env:USERPROFILE\Downloads\AION_SnapTrade_Preview_Window_Fix.zip" -DestinationPath . -Force

Test market-hours check (does not call SnapTrade):
.\.venv\Scripts\python.exe .\aion_snaptrade_options.py preview-window

Next trading day only, when SPY markets open and listed SPY options bid/ask is current:
powershell -NoProfile -ExecutionPolicy Bypass -File .\test_option_preview.ps1

Do not reuse yesterday's SPY option. No order placement method exists in these files.
If failure still HTTP 503 / code 3002 / downstream 417, contact SnapTrade support
with the code triple, account brokerage Webull Canada CASH, time/timezone,
correct live OCC symbol (redact account ID and tokens), option right/action,
and ask if preview is currently supported for your account. Avoid posting raw errors.
