$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'AION SnapTrade preflight: validating ONLY your configured Webull CASH account...'
& .\.venv\Scripts\python.exe .\aion_snaptrade_options.py account
if ($LASTEXITCODE -ne 0) { throw "Account preflight failed (exit $LASTEXITCODE)" }
Write-Host 'Success. The script has no order submission function.'
