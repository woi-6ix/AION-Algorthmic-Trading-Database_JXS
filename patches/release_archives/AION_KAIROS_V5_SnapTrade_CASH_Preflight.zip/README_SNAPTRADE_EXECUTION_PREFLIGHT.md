# AION KAIROS V5 — SnapTrade / Webull Canada CASH preflight (no trading)

This addition **does not place broker orders**, does not alter your TradingView KAIROS V5 logic, does not change existing simulator and gateway endpoints, and retains your current `.env`. Its sole purpose is to verify the selected real Webull Canada CASH account, build correctly structured 0DTE *candidate* long CALL or PUT order tickets, and optionally diagnose SnapTrade's **BETA** `get_option_impact` endpoint. There is deliberately no option-order submission function anywhere in this package. A successful impact preview is not a paper-trade or live order.

## Installation

1. Download the ZIP and extract its files into `C:\Users\sathw\AION-Execution`, selecting **Replace** for the bundled simulator/gateway files if asked (their contents are unchanged from the previous webhook package). Do not delete `.env`, your virtual environment, the database or existing scripts; none are included in this ZIP. These scripts do not upload or expose API keys.
2. In PowerShell:

```powershell
cd C:\Users\sathw\AION-Execution
.\.venv\Scripts\python.exe -m pip install snaptrade-python-sdk python-dotenv tzdata
powershell -NoProfile -ExecutionPolicy Bypass -File .\test_snaptrade_cash.ps1
```

Success prints `SUCCESS: Selected brokerage account was verified` and `Webull CASH`. Any margin account, missing account type, ID mismatch, unexpected name or non-SIMULATION configuration fails closed. **Do not share `.env` or account IDs.**

## Make a candidate SPY 0DTE ticket without network trading calls

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\test_option_ticket.ps1
```

Choose C or P, manually find **today's valid SPY 0DTE strike** and an option premium from your own trading platform, and enter these values. **The suggested numbers in the prompts are examples, NOT live market quotes.** The script builds the 21-character OCC contract, computes `limit_price * 100 * contracts` (before fees/FX), checks the configured max premium (default $2,500 USD) and that expiry equals today's New York date. It does NOT verify that the option is listed, receive real-time bid/ask, or verify buying power. For safety this version supports `BUY_TO_OPEN` only. Fees and exchange conversion may increase required cash. No order is submitted.

An equivalent CLI call:

```powershell
.\.venv\Scripts\python.exe .\aion_snaptrade_options.py ticket --right C --strike 680 --limit 2.50 --contracts 1
```

**680 and $2.50 are purely illustrative and must be replaced with the actual same-day option contract and a recent broker quote.** The command will refuse weekend dates and any different expiry.

## Retry broker option order impact (BETA) — only when an actual 0DTE contract is listed

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\test_option_preview.ps1
```

This verifies the CASH account live then calls only:

```python
client.trading.get_option_impact(...)
```

It NEVER calls `place_mleg_order` or any other order-placement endpoint. The preview endpoint is **BETA** and its request/response can change without notice. Your earlier error was SnapTrade HTTP 503 / code 3002 / downstream status 417. If that recurs, save **only** the three error codes, the date/time, the fact that it's Webull Canada CASH, and the fact that it's a single-leg `BUY_TO_OPEN` SPY 0DTE LIMIT order when contacting SnapTrade support. Do not post any API credentials or the request payload with account ID.

When the market is closed, an impact request for 0DTE options may be refused; test with a valid option during the normal U.S. session. A failed impact preview alone does not prove that actual option order placement is unsupported. Never use a live order to test this until the complete audited executor is built and explicitly approved.

## Controls

- `AION_MODE=SIMULATION` enforced; this tool has no live mode.
- `AION_ALLOWED_STRATEGY=KAIROS_V5` enforced.
- `SNAPTRADE_CASH_ACCOUNT_ID` must identify a Webull CASH account; margin account is rejected.
- Optional `.env` setting: `AION_MAX_OPTION_PREMIUM_USD=2500` (default already 2500).
- Maximum 10 long contracts per ticket; premium cap is checked before brokerage call.
- No secret, full account ID or raw API exception body is printed.
- No trading submission, webhook routing into SnapTrade, or option auto-selection exists yet.

## Offline self-test

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -p "test_aion_snaptrade_options.py" -v
```

## Next engineering stage, not enabled now

1. Live option-chain provider with verified OCC symbols, bid/ask, quote timestamps, and spread checks.
2. Read-only balance/position reconciliation on Webull CASH, no mixing with MARGIN.
3. Stateful, durable order queue with user confirmation, order submission via SnapTrade's separate **place option order** endpoint only once authorized, fill/cancel reconciliation, duplicate retries and kill switch.
4. Risk and exchange-calendar enforcement; 0DTE cash settlement, order cutoff, exit/failure handling; never equate a TradingView simulated strategy fill to a brokerage option fill.
5. Broker/SnapTrade approval for your intended unattended, ML-signal-driven execution. SnapTrade's compliance policy differentiates consenting to specific rules-based automated orders from blanket discretionary trading authority.

**Note:** Cloudflare Quick Tunnels and this testing gateway are development-only and must never forward directly to live brokerage order placement.

Documentation: https://docs.snaptrade.com/docs/trading-with-snaptrade ; https://docs.snaptrade.com/reference/Trading/Trading_getOptionImpact ; https://docs.snaptrade.com/reference/Trading/Trading_placeMlegOrder .
