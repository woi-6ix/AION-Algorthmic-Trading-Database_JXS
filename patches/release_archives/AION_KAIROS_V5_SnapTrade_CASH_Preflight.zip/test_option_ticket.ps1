$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'AION SPY 0DTE OPTIONS TICKET (no order placement)'
Write-Host 'Use your own current-day strike and manually verified limit price from Webull.'
$right = (Read-Host 'Option right (C=CALL, P=PUT)').Trim().ToUpper()
$strike = (Read-Host 'Strike price (e.g., 680)').Trim()
$limit = (Read-Host 'Limit option premium PER SHARE in USD (e.g., 2.50)').Trim()
$contracts = (Read-Host 'Number of contracts (e.g., 1)').Trim()
& .\.venv\Scripts\python.exe .\aion_snaptrade_options.py ticket --right $right --strike $strike --limit $limit --contracts $contracts
if ($LASTEXITCODE -ne 0) { throw "Ticket validation failed (exit $LASTEXITCODE)" }
Write-Host 'No requests to trading API made. No orders placed.'
