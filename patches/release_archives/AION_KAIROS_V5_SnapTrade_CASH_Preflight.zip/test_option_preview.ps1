$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'This uses SnapTrade BETA get_option_impact (preview only).'
Write-Host 'NO BROKERAGE ORDER WILL BE SENT, even if the preview succeeds.'
$right = (Read-Host 'Option right (C=CALL, P=PUT)').Trim().ToUpper()
$strike = (Read-Host 'Strike price from Webull 0DTE option chain').Trim()
$limit = (Read-Host 'Limit premium per option share USD, from your own option quote').Trim()
$contracts = (Read-Host 'Number of contracts').Trim()
& .\.venv\Scripts\python.exe .\aion_snaptrade_options.py preview --right $right --strike $strike --limit $limit --contracts $contracts
if ($LASTEXITCODE -ne 0) { throw "Impact preview returned an error (exit $LASTEXITCODE); no order placed" }
Write-Host 'Brokerage orders placed: 0'
