import sys
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from aion_snaptrade_options import build_ticket, verify_cash_details, safe_preview_error

TODAY = date(2026, 11, 5)


class TestTicket(unittest.TestCase):
    def test_spy_0dte_call_occ(self):
        t = build_ticket('C', '680', '2.50', 1, today=TODAY)
        self.assertEqual(t.symbol, 'SPY   261105C00680000')
        self.assertEqual(len(t.symbol), 21)
        self.assertEqual(t.maximum_premium_usd, 250)

    def test_put_occ(self):
        t = build_ticket('P', '679.5', '0.75', 2, today=TODAY)
        self.assertEqual(t.symbol, 'SPY   261105P00679500')
        self.assertEqual(t.maximum_premium_usd, 150)

    def test_budget_rejection(self):
        with self.assertRaises(ValueError):
            build_ticket('C', '680', '26.00', 1, today=TODAY)

    def test_nonzero_positive_prices_and_precision(self):
        for x in ('0', '-1', 'NaN', '2.555'):
            with self.assertRaises(ValueError):
                build_ticket('C', '680', x, 1, today=TODAY)

    def test_not_0dte(self):
        with self.assertRaises(ValueError):
            build_ticket('P', '670', '1.50', 1, expiry=date(2026, 11, 6), today=TODAY)

    def test_weekend(self):
        with self.assertRaises(ValueError):
            build_ticket('P', '670', '1.50', 1, today=date(2026, 11, 7))

    def test_cash_guard(self):
        cash = {'id': 'test-001', 'name': 'Webull CASH', 'raw_type':'CASH', 'cash_or_margin':'cash','is_paper':False}
        self.assertEqual(verify_cash_details(cash, 'test-001')['name'], 'Webull CASH')
        with self.assertRaises(RuntimeError):
            verify_cash_details({**cash, 'name':'Webull MARGIN', 'raw_type':'MARGIN'}, 'test-001')
        with self.assertRaises(RuntimeError):
            verify_cash_details(cash, 'test-002')
        with self.assertRaises(RuntimeError):
            verify_cash_details({**cash, 'name':'Other Broker CASH'}, 'test-001')

    def test_preview_error_codes_only(self):
        class FakeException(Exception):
            status_code = 503
            body = {'code': 3002, 'detail': 'request failed with status code 417', 'secret':'DO_NOT_SHOW'}
        result = safe_preview_error(FakeException())
        self.assertIn('503', result)
        self.assertIn('3002', result)
        self.assertIn('417', result)
        self.assertNotIn('DO_NOT_SHOW', result)

if __name__ == '__main__':
    unittest.main()
