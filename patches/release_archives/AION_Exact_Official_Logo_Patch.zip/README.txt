AION QUANT LABS — EXACT UPLOADED LOGO UPDATE

This package embeds your exact uploaded PNG (1,254 x 1,254 RGBA) in the
AION desktop/sidebar and mobile/header, plus favicon. PNG is copied byte
for byte without recompression or retouching. It preserves AION trading
servers, .env, signal logs, Tailscale Serve, and trading logic.

1. Copy the downloaded ZIP into your Downloads directory.
2. In PowerShell:
   cd C:\Users\sathw\AION-Execution
   Expand-Archive -Path "$env:USERPROFILE\Downloads\AION_Exact_Official_Logo_Patch.zip" -DestinationPath . -Force
   .\.venv\Scripts\python.exe .\apply_exact_aion_logo.py
3. Refresh http://127.0.0.1:8501 on PC and your private Tailscale
   website on iPhone. If the image isn't served, restart ONLY the
   existing dashboard process, leaving ports 8001/8002 alone.

This is not a replacement for your full dashboard or a SnapTrade patch.
