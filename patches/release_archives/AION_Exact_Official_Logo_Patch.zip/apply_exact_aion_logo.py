"""Install the exact unmodified user-supplied AION PNG in the AION live dashboard.

Updates only the dashboard logo asset, logo URL, and, if not already present,
the read-only logo static file route/brand markup. Never touches trading state.
"""
from __future__ import annotations

import ast
import hashlib
import re
import shutil
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'aion_live_dashboard.py'
PAGE = ROOT / 'static' / 'index.html'
SOURCE_LOGO = ROOT / 'brand_asset' / 'aion-exact-upload.png'
DEST_LOGO = ROOT / 'static' / 'aion-logo.png'
EXPECTED_SHA256 = '2eb66ab2f80c6e3c954c841bdcdaebeb615054179d09c013219df026799a3cff'

ROUTE = '''@app.get("/static/aion-logo.png", include_in_schema=False)
def aion_brand_logo():
    """Serve the approved AION PNG; other private files remain inaccessible."""
    return FileResponse(
        ROOT / "static" / "aion-logo.png",
        media_type="image/png",
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )


'''
CSS = '''\n    .mark.brand-logo{display:block;width:48px;height:48px;object-fit:contain;flex-shrink:0;background:transparent;border:none;border-radius:50%;box-shadow:0 0 16px rgba(232,186,104,.12)}
    .mobiletop .mark.brand-logo{width:36px;height:36px;object-fit:contain;border-radius:50%;box-shadow:none}
'''
DESKTOP_OLD = '<div class="brand"><div class="mark">A</div>'
MOBILE_OLD = '<div class="mobiletop"><div class="mark">A</div>'
DESKTOP_NEW = '<div class="brand"><img class="mark brand-logo" src="/static/aion-logo.png" alt="AION Quant Labs logo" width="48" height="48" />'
MOBILE_NEW = '<div class="mobiletop"><img class="mark brand-logo" src="/static/aion-logo.png" alt="AION Quant Labs logo" width="36" height="36" />'


def patched(app: str, html: str) -> tuple[str, str]:
    if '@app.get("/static/aion-logo.png"' not in app:
        anchor = '@app.get("/")'
        if app.count(anchor) != 1:
            raise RuntimeError('Could not identify dashboard root route; no changes made.')
        app = app.replace(anchor, ROUTE + anchor, 1)
    if DESKTOP_OLD in html:
        if html.count(DESKTOP_OLD) != 1:
            raise RuntimeError('Unrecognized desktop header; no changes made.')
        html = html.replace(DESKTOP_OLD, DESKTOP_NEW, 1)
    if MOBILE_OLD in html:
        if html.count(MOBILE_OLD) != 1:
            raise RuntimeError('Unrecognized mobile header; no changes made.')
        html = html.replace(MOBILE_OLD, MOBILE_NEW, 1)
    if '.mark.brand-logo{' not in html:
        anchor = '.mobilenav{display:none}.mobiletop{display:none}'
        if html.count(anchor) != 1:
            raise RuntimeError('Unrecognized CSS layout; no changes made.')
        html = html.replace(anchor, anchor + CSS, 1)
    if '<link rel="icon" type="image/png"' not in html:
        anchor = '<title>AION | Live Trading Monitor</title>'
        if html.count(anchor) != 1:
            raise RuntimeError('Unrecognized page title; no changes made.')
        html = html.replace(anchor, anchor + '\n  <link rel="icon" type="image/png" href="/static/aion-logo.png" />\n  <link rel="apple-touch-icon" href="/static/aion-logo.png" />', 1)
    if 'class="mark brand-logo"' not in html or 'src="/static/aion-logo.png' not in html:
        raise RuntimeError('Logo locations not recognized; no changes made.')
    # New URL so Safari/iPhone doesn't continue showing the old cached image.
    url = '/static/aion-logo.png?v=' + EXPECTED_SHA256[:12]
    html = re.sub(r'/static/aion-logo\.png(?:\?v=[0-9a-f]+)?', url, html)
    ast.parse(app)
    return app, html


def main():
    for target in (APP, PAGE, SOURCE_LOGO):
        if not target.is_file():
            raise SystemExit(f'Missing: {target}. Extract ZIP in C:\\Users\\sathw\\AION-Execution and try again.')
    logo = SOURCE_LOGO.read_bytes()
    digest = hashlib.sha256(logo).hexdigest()
    if digest != EXPECTED_SHA256:
        raise SystemExit('Uploaded logo file failed integrity check; nothing changed.')
    original_app = APP.read_text(encoding='utf-8')
    original_html = PAGE.read_text(encoding='utf-8')
    new_app, new_html = patched(original_app, original_html)
    backup_dir = ROOT / 'aion-logo-backups' / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup_dir.mkdir(parents=True, exist_ok=False)
    shutil.copy2(APP, backup_dir / APP.name)
    shutil.copy2(PAGE, backup_dir / 'index.html')
    if DEST_LOGO.is_file():
        shutil.copy2(DEST_LOGO, backup_dir / 'aion-logo.png')
    DEST_LOGO.write_bytes(logo)  # IMPORTANT: exact original bytes; no image conversion, resize or recoloring
    if new_app != original_app:
        APP.write_text(new_app, encoding='utf-8')
    if new_html != original_html:
        PAGE.write_text(new_html, encoding='utf-8')
    assert hashlib.sha256(DEST_LOGO.read_bytes()).hexdigest() == EXPECTED_SHA256
    print('SUCCESS: Exact uploaded AION Quant Labs logo installed, byte-for-byte.')
    print('Desktop header, mobile header and favicon use the original PNG.')
    print('SHA-256:', digest)
    print('Dashboard files backed up to:', backup_dir)
    print('No trade records, trading settings, SnapTrade credentials or order functions changed.')
    print('Refresh Safari; if missing, restart only aion_live_dashboard on port 8501.')

if __name__ == '__main__':
    main()
