# AION KAIROS V1 — Signal Reception (Simulation Only)

This small project is **not an options trader**. It can receive an HTTP JSON signal, reject invalid/stale/duplicate events, and log directional signal intent in SQLite. It never places or simulates real broker executions. There is no order-routing code.

## Install on Windows

1. Extract these five files into your **existing** `C:\Users\sathw\AION-Execution` folder, next to your existing `.env`. Do not replace or disclose `.env`.
2. In that folder run:

   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r requirements-aion.txt
   ```

3. Add these **non-secret** lines to your `.env` (preserve existing SnapTrade values):

   ```dotenv
   AION_MODE=SIMULATION
   AION_ALLOWED_STRATEGY=KAIROS_V4_1_2
   AION_MAX_SIGNAL_AGE_SECONDS=180
   AION_ENFORCE_SESSION=false
   ```

4. In PowerShell terminal #1 start the app:

   ```powershell
   .\start_aion.ps1
   ```

   If Windows PowerShell blocks `.ps1` scripts, use the executable command directly instead:

   ```powershell
   .\.venv\Scripts\python.exe -m uvicorn aion_kairos_server:app --host 127.0.0.1 --port 8000
   ```

5. In terminal #2 test:

   ```powershell
   .\test_aion.ps1
   ```

   You should receive `broker_order_sent: False` and `SIGNAL_LOGGED` the first time. If the state is already CALL_INTENT from an earlier test, you will see `IGNORED_ALREADY_SIGNALED`. Both are safe.

6. Open `http://127.0.0.1:8000/health` for the local status, and `http://127.0.0.1:8000/events` for recent signal results.

## Payload expected by the simulation endpoint

```json
{
  "event_id": "kairos-20261104-001",
  "strategy": "KAIROS_V4_1_2",
  "symbol": "SPY",
  "timeframe": "3m",
  "signal": "BUY_CALL",
  "emitted_at": "2026-11-04T18:00:00Z"
}
```

The `event_id` must be unique per true signal. The `emitted_at` timestamp must be current, timezone-aware UTC, and within 180 seconds. Permitted signals: `BUY_CALL`, `BUY_PUT`, and `EXIT`. `EXIT` clears **only the simulator's directional intent**; it does not close any real position.

## Deliberate constraints

- The server refuses to start if `AION_MODE` is not `SIMULATION`.
- No order submit function or other brokerage call is present.
- Your original `.env` contains your cash account ID; the service checks that it exists but does not read or transmit brokerage credentials.
- The service is bound to `127.0.0.1`. **Never publish port 8000 or bind to 0.0.0.0**.
- This local test is not authenticated for the internet. Before receiving actual TradingView webhooks, put a hardened HTTPS reverse proxy/relay in front, authenticate the source (e.g., IP allowlisting + TradingView certificate where supported), protect status endpoints, queue signals, and keep broker secrets off the webhook.
- `AION_ENFORCE_SESSION=false` is for local tests after hours. Production must enforce New York hours **and exchange holidays**, late-entry restrictions, closeout and failure recovery.
- It does not verify or place option contracts, obtain options quotes, calculate options P&L, maintain broker positions, or handle filled/partial/canceled orders.
- Disable duplicate/conflicting KAIROS strategy versions before going live. Only use one strategy ID at a time.
- This program's 3-minute interval means 3-minute KAIROS bar signals, not a 3-minute polling loop.

## Next stages (not implemented)

1. Modify the chosen KAIROS Pine strategy to emit a correctly mapped event type for **entry, reversal, and exit**; order actions alone are not enough to disambiguate all options actions.
2. Put an HTTPS endpoint on port 443 with source verification, latency logging, durable retries, and an internal worker queue. TradingView webhook alerts need 2FA and can time out after 3 seconds.
3. Connect a licensed real-time options-chain/quote source, verify exact OCC contract, ask/size/spread/OPRA access, buying power and 0DTE cutoff.
4. Implement risk controls: maximum loss and notional exposure, one-position-at-a-time, idempotency, kill switch, cash-only account invariant, emergency flatten, and exchange holidays.
5. Validate SnapTrade + Webull Canada's actual order submit, cancel, order-state and exit operations in an authorized sandbox or paper workflow. The prior option impact preview returned HTTP 503 / error 3002 / downstream 417; an impact preview is not itself proof of trading support.
6. Clarify SnapTrade policy on unattended ML-based trading before enabling any live automated order submissions. Personal API trade capabilities do not imply ChatGPT MCP trading access.
